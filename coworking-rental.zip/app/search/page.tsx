"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { MapPin, Star, Users } from "lucide-react"
import Image from "next/image"
import { useState } from "react"

// Sample coworking spaces data
const coworkingSpaces = [
  {
    id: 1,
    name: "Downtown Hub",
    address: "123 Business St, Downtown",
    price: 25,
    rating: 4.8,
    reviews: 124,
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["Wifi", "Coffee", "Parking", "Meeting Rooms"],
    capacity: 50,
    availability: "Available",
    lat: 40.7128,
    lng: -74.006,
  },
  {
    id: 2,
    name: "Creative Space",
    address: "456 Art District, Midtown",
    price: 30,
    rating: 4.6,
    reviews: 89,
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["Wifi", "Coffee", "Printing", "24/7 Access"],
    capacity: 30,
    availability: "Available",
    lat: 40.7589,
    lng: -73.9851,
  },
  {
    id: 3,
    name: "Tech Valley",
    address: "789 Innovation Ave, Tech District",
    price: 35,
    rating: 4.9,
    reviews: 156,
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["Wifi", "Coffee", "Parking", "Phone Booths"],
    capacity: 75,
    availability: "Limited",
    lat: 40.7505,
    lng: -73.9934,
  },
  {
    id: 4,
    name: "Startup Lounge",
    address: "321 Entrepreneur Blvd, Financial District",
    price: 28,
    rating: 4.7,
    reviews: 203,
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["Wifi", "Coffee", "Event Space", "Mentorship"],
    capacity: 40,
    availability: "Available",
    lat: 40.7074,
    lng: -74.0113,
  },
]

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [priceRange, setPriceRange] = useState([20, 50])
  const [selectedSpace, setSelectedSpace] = useState<number | null>(null)

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex h-screen">
        {/* Left Panel - Search and Results */}
        <div className="w-full lg:w-1/2 flex flex-col">
          {/* Search Header */}
          <div className="bg-white p-6 border-b">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Find Coworking Spaces</h1>

            {/* Search Filters */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="Enter city or address"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Space Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Any type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hot-desk">Hot Desk</SelectItem>
                      <SelectItem value="dedicated-desk">Dedicated Desk</SelectItem>
                      <SelectItem value="private-office">Private Office</SelectItem>
                      <SelectItem value="meeting-room">Meeting Room</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Capacity</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Any size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 people</SelectItem>
                      <SelectItem value="11-25">11-25 people</SelectItem>
                      <SelectItem value="26-50">26-50 people</SelectItem>
                      <SelectItem value="50+">50+ people</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>
                  Price Range (per day): ${priceRange[0]} - ${priceRange[1]}
                </Label>
                <Slider value={priceRange} onValueChange={setPriceRange} max={100} min={10} step={5} className="mt-2" />
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">{coworkingSpaces.length} spaces found</p>
                <Select>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="distance">Distance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {coworkingSpaces.map((space) => (
                <Card
                  key={space.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedSpace === space.id ? "ring-2 ring-blue-500" : ""
                  }`}
                  onClick={() => setSelectedSpace(space.id)}
                >
                  <CardContent className="p-0">
                    <div className="flex">
                      <div className="relative w-32 h-32 flex-shrink-0">
                        <Image
                          src={space.image || "/placeholder.svg"}
                          alt={space.name}
                          fill
                          className="object-cover rounded-l-lg"
                        />
                      </div>
                      <div className="flex-1 p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg">{space.name}</h3>
                            <p className="text-sm text-gray-600 flex items-center">
                              <MapPin className="w-4 h-4 mr-1" />
                              {space.address}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-xl font-bold">${space.price}</p>
                            <p className="text-sm text-gray-600">per day</p>
                          </div>
                        </div>

                        <div className="flex items-center mb-2">
                          <div className="flex items-center">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="ml-1 text-sm font-medium">{space.rating}</span>
                            <span className="ml-1 text-sm text-gray-600">({space.reviews} reviews)</span>
                          </div>
                          <Badge
                            variant={space.availability === "Available" ? "default" : "secondary"}
                            className="ml-auto"
                          >
                            {space.availability}
                          </Badge>
                        </div>

                        <div className="flex items-center text-sm text-gray-600 mb-2">
                          <Users className="w-4 h-4 mr-1" />
                          <span>Up to {space.capacity} people</span>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          {space.amenities.slice(0, 3).map((amenity) => (
                            <Badge key={amenity} variant="outline" className="text-xs">
                              {amenity}
                            </Badge>
                          ))}
                          {space.amenities.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{space.amenities.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel - Map */}
        <div className="hidden lg:block w-1/2 relative">
          <div className="h-full bg-gray-200 relative">
            {/* Map Placeholder */}
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-blue-100 to-green-100">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Interactive Map</h3>
                <p className="text-gray-600">Coworking spaces will be displayed here</p>
              </div>
            </div>

            {/* Map Markers Simulation */}
            <div className="absolute top-1/4 left-1/3 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer hover:scale-110 transition-transform">
              1
            </div>
            <div className="absolute top-1/3 right-1/4 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer hover:scale-110 transition-transform">
              2
            </div>
            <div className="absolute bottom-1/3 left-1/4 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer hover:scale-110 transition-transform">
              3
            </div>
            <div className="absolute bottom-1/4 right-1/3 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer hover:scale-110 transition-transform">
              4
            </div>

            {/* Map Controls */}
            <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-2">
              <Button variant="outline" size="sm" className="mb-2 w-full">
                Zoom In
              </Button>
              <Button variant="outline" size="sm" className="w-full">
                Zoom Out
              </Button>
            </div>

            {/* Selected Space Info */}
            {selectedSpace && (
              <div className="absolute bottom-4 left-4 right-4">
                <Card className="bg-white/95 backdrop-blur">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">
                      {coworkingSpaces.find((s) => s.id === selectedSpace)?.name}
                    </CardTitle>
                    <CardDescription>{coworkingSpaces.find((s) => s.id === selectedSpace)?.address}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <span className="text-lg font-bold">
                          ${coworkingSpaces.find((s) => s.id === selectedSpace)?.price}/day
                        </span>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="ml-1 text-sm">
                            {coworkingSpaces.find((s) => s.id === selectedSpace)?.rating}
                          </span>
                        </div>
                      </div>
                      <Button size="sm">Book Now</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
