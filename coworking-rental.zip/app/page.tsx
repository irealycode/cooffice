import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Users, Wifi, Coffee, Car, Shield } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Search Card Section */}
      <section className="relative bg-gradient-to-br from-blue-50 to-indigo-100 py-20 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Main Search Card */}
          <div className="bg-white rounded-2xl shadow-2xl p-8 lg:p-12">
            <div className="text-center mb-8">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                Find Your Perfect
                <span className="text-blue-600"> Workspace</span>
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Discover and book premium coworking spaces in your city. From hot desks to private offices.
              </p>
            </div>

            {/* Search Form */}
            <div className="bg-gray-50 rounded-xl p-6 lg:p-8 mb-6">
              <div className="grid lg:grid-cols-3 gap-6">
                {/* City Selection */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    <MapPin className="w-4 h-4 inline mr-2 text-blue-600" />
                    Select City
                  </label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
                    <option value="">Choose your city...</option>
                    <option value="new-york">New York City</option>
                    <option value="san-francisco">San Francisco</option>
                    <option value="london">London</option>
                    <option value="tokyo">Tokyo</option>
                    <option value="singapore">Singapore</option>
                    <option value="berlin">Berlin</option>
                    <option value="toronto">Toronto</option>
                    <option value="sydney">Sydney</option>
                  </select>
                </div>

                {/* Workspace Type */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    <Users className="w-4 h-4 inline mr-2 text-blue-600" />
                    Workspace Type
                  </label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
                    <option value="">Select workspace...</option>
                    <option value="hot-desk">🔥 Hot Desk</option>
                    <option value="dedicated-desk">🎯 Dedicated Desk</option>
                    <option value="private-office">🏢 Private Office</option>
                    <option value="meeting-room">🤝 Meeting Room</option>
                    <option value="event-space">🎪 Event Space</option>
                    <option value="phone-booth">📞 Phone Booth</option>
                  </select>
                </div>

                {/* Search Button */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-transparent">Search</label>
                  <Button asChild size="lg" className="w-full h-12 text-lg font-semibold">
                    <Link href="/search">Find Spaces</Link>
                  </Button>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-gray-200">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">500+</div>
                  <div className="text-sm text-gray-600">Locations</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">10K+</div>
                  <div className="text-sm text-gray-600">Happy Members</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">24/7</div>
                  <div className="text-sm text-gray-600">Support</div>
                </div>
              </div>
            </div>

            {/* Popular Searches */}
            <div className="text-center">
              <p className="text-sm text-gray-500 mb-4">Popular searches:</p>
              <div className="flex flex-wrap justify-center gap-2">
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm hover:bg-blue-200 transition-colors cursor-pointer">
                  NYC Private Office
                </span>
                <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm hover:bg-green-200 transition-colors cursor-pointer">
                  SF Hot Desk
                </span>
                <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm hover:bg-purple-200 transition-colors cursor-pointer">
                  London Meeting Room
                </span>
                <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm hover:bg-orange-200 transition-colors cursor-pointer">
                  Tokyo Event Space
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose Our Spaces?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide premium amenities and flexible booking options to help you work at your best.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Wifi className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle>High-Speed Internet</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Lightning-fast fiber internet with dedicated bandwidth for seamless video calls and file transfers.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Coffee className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>Premium Amenities</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Complimentary coffee, tea, printing services, and fully equipped meeting rooms available 24/7.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle>Vibrant Community</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Connect with like-minded professionals, attend networking events, and grow your business network.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-6 h-6 text-orange-600" />
                </div>
                <CardTitle>Prime Locations</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Strategically located spaces in business districts with easy access to public transportation.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Car className="w-6 h-6 text-red-600" />
                </div>
                <CardTitle>Parking Available</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Secure parking spaces available for daily, weekly, and monthly bookings at competitive rates.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-indigo-600" />
                </div>
                <CardTitle>Secure Access</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  24/7 security with keycard access, CCTV monitoring, and secure storage lockers for your belongings.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Find Your Workspace?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of professionals who have found their perfect workspace with us.
          </p>
          <Button asChild size="lg" variant="secondary" className="text-lg px-8">
            <Link href="/search">Start Searching</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
